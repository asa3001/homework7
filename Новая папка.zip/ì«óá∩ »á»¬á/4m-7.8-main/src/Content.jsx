import React from 'react';

const Content = () => {
  return (
    <div>
      <h2>Добро пожаловать!</h2>
    </div>
  );
};

export default Content;